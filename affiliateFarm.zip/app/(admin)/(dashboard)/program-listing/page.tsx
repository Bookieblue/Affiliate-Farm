import DemoPage from '@/components/tables/ad-listing/page'
import AdsPage from '@/components/tables/program-listing/page';

import React from 'react'




const page = () => {
  return (
    <section  className='mt-32 padding-container'>
        <AdsPage />
    </section>
  )
}

export default page;