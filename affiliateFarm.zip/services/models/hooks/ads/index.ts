export const ADS_QUERY_KEY = 'AdsQueryKey'
