export const CATEGORY_QUERY_KEY = 'CategoryQueryKey'
