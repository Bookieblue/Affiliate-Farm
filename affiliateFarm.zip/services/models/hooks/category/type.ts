export interface CategoryResponse {
  name: string
  code: string
  program_no?: number
  created_at?: string
  updated_at?: string
}
