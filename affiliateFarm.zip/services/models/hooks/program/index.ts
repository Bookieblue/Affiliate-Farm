export const PROGRAM_QUERY_KEY = 'ProgramQueryKey'
